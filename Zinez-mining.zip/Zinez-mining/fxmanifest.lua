name "Zinez-Mining"
author "Zinez"
version "v2.4.3"
description "Mining Script By Zinez"
fx_version "cerulean"
game "gta5"

shared_scripts { 'config.lua', 'shared/*.lua', 'locales/*.lua' }
server_script { 'server.lua' }
client_scripts { 'client.lua' }

lua54 'yes'